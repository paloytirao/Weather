import React from 'react'
import './App.css'

function App() {
      const [w,sw]=React.useState({});
      const [c,sc]=React.useState('');
      const API_KEY=import.meta.env.VITE_OPENWEATHER_KEY;

      const fw=async()=>
      {
        try
        {
          const r=await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${c}&units=metric&appid=${API_KEY}`);
          const data=await r.json();
          sw(data);
        }
        catch (err)
        {
          console.error(err);
        }
      };

      const hcc=(e)=>
      {sc(e.target.value);};
      const hs=()=>
      {fw();};

    



  return (
    <>
    <div>
      <div className='pad'>
      <p>Weather App</p>
        <input type="text" value={c} onChange={hcc} placeholder='Enter Location'/>
         <button className='b' onClick={hs}>Search</button>
         {w.main&&
         (
          <div>
            <h2> Weather in {w.name}</h2>
            <p>Temperature: {w.main.temp}℃</p>
            <p>Humidity: {w.main.humidity}%</p>
            <p> Weather: {w.weather[0].description}</p>
          </div>
         )}       
      </div></div>
    </>
  );
}

export default App
